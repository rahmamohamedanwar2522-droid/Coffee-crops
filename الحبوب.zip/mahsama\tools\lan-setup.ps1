﻿# ============================================================
#  إعداد مرة واحدة فقط (يُشغَّل بصلاحية مسؤول):
#  يسمح للخادم باستقبال اتصالات أجهزة شبكة الواي فاي على المنفذ 8080
#
#  التشغيل (من نافذة PowerShell مفتوحة كمسؤول):
#    powershell -ExecutionPolicy Bypass -File tools\lan-setup.ps1
#
#  ماذا يفعل:
#   1) يمنح صلاحية ربط http://+:8080/ لهذا المستخدم (URL ACL)
#   2) يضيف قاعدة جدار حماية تسمح بالدخول على TCP 8080
#  ولا يمس أي ملفات أو صور للموقع.
# ============================================================
$port = 8080

$id = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($id)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
  Write-Host "يجب تشغيل هذا السكربت بصلاحية مسؤول:" -ForegroundColor Red
  Write-Host "  اضغط Start → اكتب powershell → زر يمين → Run as Administrator" -ForegroundColor Yellow
  Write-Host "  ثم الصق:  powershell -ExecutionPolicy Bypass -File tools\lan-setup.ps1" -ForegroundColor Yellow
  exit 2
}

Write-Host "1) صلاحية ربط المنفذ $port لجميع الشبكات..." -ForegroundColor Cyan
netsh http delete urlacl url=http://+:$port/ | Out-Null
$user = "$env:USERDOMAIN\$env:USERNAME"
netsh http add urlacl url=http://+:$port/ user="$user"
if ($LASTEXITCODE -ne 0) {
  Write-Host "   فشل بالمستخدم، أجرّب بمجموعة Everyone..." -ForegroundColor Yellow
  netsh http add urlacl url=http://+:$port/ sddl="D:(A;;GX;;;S-1-1-0)"
}

Write-Host "2) قاعدة جدار الحماية للمنفذ $port..." -ForegroundColor Cyan
netsh advfirewall firewall delete rule name="AlHuboob Preview $port" | Out-Null
netsh advfirewall firewall add rule name="AlHuboob Preview $port" dir=in action=allow protocol=TCP localport=$port

Write-Host ""
Write-Host "=== التحقق ===" -ForegroundColor Green
netsh http show urlacl url=http://+:$port/
Get-NetFirewallRule -DisplayName "AlHuboob Preview $port" -ErrorAction SilentlyContinue |
  Select-Object DisplayName, Enabled, Direction, Action | Format-Table -AutoSize
Write-Host "انتهى الإعداد — يمكنك الآن تشغيل:  powershell -ExecutionPolicy Bypass -File serve.ps1" -ForegroundColor Green
