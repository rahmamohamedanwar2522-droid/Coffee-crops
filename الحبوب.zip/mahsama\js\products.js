/* ============================================================
   بيانات المنتجات — الحبوب
   الأسعار كلها تجريبية (بالجنيه المصري) وقابلة للتعديل من هنا.
   كل منتج: id فريد، اسم، قسم، سعر، وزن، وصف، صورة، وسعر قديم اختياري للخصم.
   ============================================================ */
window.PRODUCTS = [
  {
    id: "coffee-brazil",
    name: "البن البرازيلي المحمص",
    category: "coffee",
    price: 450,
    oldPrice: 520,
    weight: "١ كجم",
    badge: "الأكثر مبيعًا",
    desc: "حبوب بن برازيلية درجة أولى، محمصة على دفعات صغيرة حتى تصل لدرجة الوسط الداكنة. نكهة كراميل ولوز مع حموضة خفيفة وطعم قوي مناسب للإسبريسو والقهوة العربية.",
    image: "images/coffee-brazil.jpg",
    featured: true
  },
  {
    id: "coffee-colombia",
    name: "البن الكولومبي المحمص",
    category: "coffee",
    price: 480,
    oldPrice: null,
    weight: "١ كجم",
    badge: "فاخر",
    desc: "بن كولومبي عالي الجودة من مزارع الأنديز، يتميز بنكهته المتوازنة وحموضته اللطيفة ورائحته الزكية. مثالي للقهوة بالتقطير V60 وللتحضير اليومي.",
    image: "images/coffee-colombia.jpg",
    featured: true
  },
  {
    id: "coffee-turkish",
    name: "البن التركي المطحون",
    category: "coffee",
    price: 260,
    oldPrice: 300,
    weight: "٥٠٠ جرام",
    badge: "عرض",
    desc: "بن تركي مطحون ناعمًا جدًا كالبودرة، مثالي للقهوة التركية في الركوة مع الهيل. تحميص فاتح يحافظ على الرائحة والنكهة الأصيلة.",
    image: "images/coffee-turkish.jpg",
    featured: true
  },
  {
    id: "coffee-ground",
    name: "القهوة العربية المطحونة",
    category: "coffee",
    price: 320,
    oldPrice: null,
    weight: "٥٠٠ جرام",
    badge: null,
    desc: "خليط قهوة عربي متوازن مطحون طازجًا يوميًا، يناسب الإسبريسو والقهوة بالحليب. يمكنك طلب درجة الطحن المناسبة لك عبر واتساب.",
    image: "images/coffee-ground.jpg",
    featured: false
  },
  {
    id: "coffee-green",
    name: "البن الأخضر (غير محمص)",
    category: "coffee",
    price: 380,
    oldPrice: null,
    weight: "١ كجم",
    badge: "للمحمّصات",
    desc: "حبوب بن خضراء طبيعية غير محمصة، مخصصة للمحمّصات ومن يحب تحميص القهوة بنفسه في المنزل. بذور منتقاة بدون كسر أو عيوب.",
    image: "images/coffee-green.jpg",
    featured: false
  },
  {
    id: "coffee-instant",
    name: "قهوة فورية بالكريمة",
    category: "coffee",
    price: 180,
    oldPrice: 210,
    weight: "٤٠٠ جرام",
    badge: "عرض",
    desc: "قهوة فورية غنية بالكريمة، تحضير سريع بالماء الساخن أو الحليب. مذاق سلس ومتوازن يناسب المكاتب والبيت.",
    image: "images/coffee-cup.jpg",
    featured: true
  },

  /* ==================== القهوة المختصة ==================== */
  {
    id: "specialty-ethiopia",
    name: "قهوة إثيوبية يرقاتشيف",
    category: "specialty",
    price: 690,
    oldPrice: null,
    weight: "٢٥٠ جرام",
    badge: "مختصة",
    desc: "حبوب إثيوبية أصلية من منطقة يرقاتشيف، تحميص فاتح يُبرز الحموضة الفاكهية والرائحة الزهرية. مثالية للتقطير V60 والمقلاة الهوائية.",
    image: "images/specialty-ethiopia.jpg",
    featured: true
  },
  {
    id: "specialty-pourover",
    name: "قهوة بالتقطير V60 — خليط مختص",
    category: "specialty",
    price: 540,
    oldPrice: 600,
    weight: "٢٥٠ جرام",
    badge: "تقطير",
    desc: "خليط مختص مطحون وفق درجة التقطير المناسبة، حلوية متوازنة وحموضة نظيفة مع نكهة الشوكولاتة والكراميل، ويُحضّر بالماء على حرارة ٩٢°م.",
    image: "images/specialty-pourover.jpg",
    featured: true
  },
  {
    id: "specialty-espresso",
    name: "خليط الإسبريسو المختص",
    category: "specialty",
    price: 580,
    oldPrice: null,
    weight: "٥٠٠ جرام",
    badge: "جديد",
    desc: "خليط حبوب محمصة حديثًا مخصص لمكائن الإسبريسو، كريما كثيفة وطعم شوكولاتوي مع لمسة كراميل، مناسب للحليب والمشروبات الساخنة.",
    image: "images/specialty-espresso.jpg",
    featured: false
  }
];

/* أسماء الأقسام للعرض */
window.CATEGORIES = {
  coffee: "القهوة والبن",
  specialty: "القهوة المختصة"
};
