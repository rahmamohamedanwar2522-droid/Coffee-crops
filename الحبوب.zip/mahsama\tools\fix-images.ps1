# Fix missing/duplicate images (run after get-images.ps1)
$ErrorActionPreference = "Stop"
$ua = "MahsamaSiteImages/1.0 (personal site build; contact: site-owner@example.com)"
$imgDir = Join-Path $PSScriptRoot "..\images"

$jobs = @(
    @{ key = "coffee-ground";   q = "ground coffee" },
    @{ key = "coffee-green";    q = "green coffee beans unroasted" },
    @{ key = "coffee-turkish";  q = "Turkish coffee cezve" }
)

function Invoke-Polite($url, $tries) {
    for ($t = 1; $t -le $tries; $t++) {
        try { return Invoke-WebRequest -Uri $url -TimeoutSec 40 -UseBasicParsing -UserAgent $ua }
        catch {
            $code = $null
            if ($_.Exception.Response) { try { $code = [int]$_.Exception.Response.StatusCode } catch {} }
            if ($code -eq 429 -or $code -eq 403 -or $t -lt $tries) {
                $wait = 25 * $t; Write-Host "  retry after ${wait}s (code=$code)"; Start-Sleep -Seconds $wait
            } else { throw }
        }
    }
}

function Search-Commons($query, $limit) {
    $q = [uri]::EscapeDataString("filetype:bitmap $query")
    $u = "https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=$q&gsrnamespace=6&gsrlimit=$limit&prop=imageinfo&iiprop=url|mime|size&iiurlwidth=1200&format=json"
    $r = Invoke-Polite $u 4
    $json = $r.Content | ConvertFrom-Json
    $out = @()
    foreach ($p in $json.query.pages.PSObject.Properties.Value) {
        $ii = $p.imageinfo[0]
        if (-not $ii -or $ii.mime -notin @("image/jpeg","image/png")) { continue }
        if ($ii.thumburl -and $ii.thumbwidth -ge 700) {
            $out += [pscustomobject]@{ title=$p.title; url=$ii.thumburl; w=$ii.thumbwidth; idx=$p.index }
        }
    }
    return @($out | Sort-Object idx)
}

foreach ($job in $jobs) {
    $dest = Join-Path $imgDir "$($job.key).jpg"
    try {
        foreach ($cand in (Search-Commons $job.q 10)) {
            try {
                $data = Invoke-Polite $cand.url 2
                if ($data.Content.Length -gt 20000) {
                    [System.IO.File]::WriteAllBytes($dest, $data.Content)
                    Write-Host "saved $($job.key).jpg <= $($cand.title) ($([math]::Round($data.Content.Length/1kb)) KB)"
                    break
                }
            } catch { Write-Host "  cand failed: $($_.Exception.Message)" }
        }
    } catch { Write-Host "FAILED $($job.key): $($_.Exception.Message)" }
    Start-Sleep -Seconds 8
}
Write-Host "done"
