/* ============================================================
   السلة — تعمل بتخزين المتصفح المحلي (localStorage)
   لا يوجد خادم ولا حفظ على الإنترنت: السلة تبقى على جهازك فقط.
   ============================================================ */
(function () {
  var KEY = "mahsama_cart_v1";
  var memory = null; // بديل في حال منع المتصفح التخزين المحلي

  function safeRead() {
    if (memory) return memory;
    try {
      var raw = window.localStorage.getItem(KEY);
      var arr = raw ? JSON.parse(raw) : [];
      if (!Array.isArray(arr)) arr = [];
      // تنظيف أي بيانات قديمة
      memory = arr.filter(function (i) {
        return i && typeof i.id === "string" && typeof i.qty === "number" && i.qty > 0;
      });
    } catch (e) {
      memory = [];
    }
    return memory;
  }

  function safeWrite(arr) {
    memory = arr;
    try {
      window.localStorage.setItem(KEY, JSON.stringify(arr));
    } catch (e) {
      /* التخزين المحلي ممنوع — تبقى السلة في الذاكرة أثناء الجلسة */
    }
  }

  function findProduct(id) {
    var list = window.PRODUCTS || [];
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return null;
  }

  var Cart = {
    /** كل عناصر السلة مع بيانات المنتج الكاملة */
    items: function () {
      return safeRead().map(function (line) {
        var p = findProduct(line.id);
        return {
          id: line.id,
          qty: line.qty,
          product: p,
          lineTotal: p ? p.price * line.qty : 0
        };
      }).filter(function (line) { return !!line.product; });
    },

    count: function () {
      return safeRead().reduce(function (s, l) { return s + l.qty; }, 0);
    },

    subtotal: function () {
      return Cart.items().reduce(function (s, l) { return s + l.lineTotal; }, 0);
    },

    /** التوصيل غير متاح حاليًا — الإجمالي = الإجمالي الفرعي */
    shipping: function () {
      return 0;
    },

    total: function () {
      return Cart.subtotal();
    },

    /** إضافة منتج (يدمج مع الكمية الموجودة) */
    add: function (id, qty) {
      qty = Math.max(1, parseInt(qty, 10) || 1);
      var arr = safeRead().slice();
      var found = null;
      for (var i = 0; i < arr.length; i++) if (arr[i].id === id) { found = arr[i]; break; }
      if (findProduct(id) === null) return false;
      if (found) found.qty = Math.min(99, found.qty + qty);
      else arr.push({ id: id, qty: Math.min(99, qty) });
      safeWrite(arr);
      return true;
    },

    /** ضبط كمية منتج بقيمة محددة */
    setQty: function (id, qty) {
      qty = parseInt(qty, 10);
      var arr = safeRead().slice();
      if (!qty || qty < 1) return Cart.remove(id);
      for (var i = 0; i < arr.length; i++) {
        if (arr[i].id === id) { arr[i].qty = Math.min(99, qty); break; }
      }
      safeWrite(arr);
    },

    remove: function (id) {
      safeWrite(safeRead().filter(function (l) { return l.id !== id; }));
    },

    clear: function () {
      safeWrite([]);
    }
  };

  window.Cart = Cart;
})();
