# Downloads product images from Wikimedia Commons into ../images/
# Usage: powershell -ExecutionPolicy Bypass -File get-images.ps1
$ErrorActionPreference = "Stop"
$ua = "MahsamaSiteImages/1.0 (educational personal site build; contact: site-owner@example.com) Mozilla/5.0"
$imgDir = Join-Path $PSScriptRoot "..\images"
New-Item -ItemType Directory -Force -Path $imgDir | Out-Null

# key = file name (without extension), q = commons search query
$jobs = @(
    @{ key = "hero-coffee";     q = "roasted coffee beans macro" },
    @{ key = "coffee-brazil";   q = "roasted arabica coffee beans" },
    @{ key = "coffee-colombia"; q = "coffee beans roasted" },
    @{ key = "coffee-turkish";  q = "Turkish coffee cezve" },
    @{ key = "coffee-ground";   q = "ground coffee powder" },
    @{ key = "coffee-green";    q = "green coffee beans unroasted" },
    @{ key = "coffee-cup";      q = "cup of coffee espresso" }
)

function Invoke-Polite($url, $tries) {
    for ($t = 1; $t -le $tries; $t++) {
        try {
            return Invoke-WebRequest -Uri $url -TimeoutSec 40 -UseBasicParsing -UserAgent $ua
        } catch {
            $code = $null
            if ($_.Exception.Response) { try { $code = [int]$_.Exception.Response.StatusCode } catch {} }
            if ($code -eq 429 -or $t -lt $tries) {
                $wait = 20 * $t
                Write-Host "  retry after ${wait}s (code=$code)"
                Start-Sleep -Seconds $wait
            } else { throw }
        }
    }
}

function Search-Commons($query, $limit) {
    $q = [uri]::EscapeDataString("filetype:bitmap $query")
    $u = "https://commons.wikimedia.org/w/api.php?action=query&generator=search&gsrsearch=$q&gsrnamespace=6&gsrlimit=$limit&prop=imageinfo&iiprop=url|mime|size&iiurlwidth=1200&format=json"
    $r = Invoke-Polite $u 4
    $json = $r.Content | ConvertFrom-Json
    $pages = $json.query.pages.PSObject.Properties.Value
    $out = @()
    foreach ($p in $pages) {
        $ii = $p.imageinfo[0]
        if (-not $ii) { continue }
        if ($ii.mime -notin @("image/jpeg", "image/png")) { continue }
        if ($ii.thumburl -and $ii.thumbwidth -ge 700) {
            $out += [pscustomobject]@{ title = $p.title; url = $ii.thumburl; w = $ii.thumbwidth; h = $ii.thumbheight; idx = $p.index }
        }
    }
    return @($out | Sort-Object idx)
}

foreach ($job in $jobs) {
    $dest = Join-Path $imgDir "$($job.key).jpg"
    if ((Test-Path $dest) -and (Get-Item $dest).Length -gt 20000) {
        Write-Host "skip  $($job.key)"
        continue
    }
    $ok = $false
    try {
        $results = Search-Commons $job.q 10
        foreach ($cand in $results) {
            try {
                $data = Invoke-Polite $cand.url 3
                if ($data.Content.Length -gt 20000) {
                    [System.IO.File]::WriteAllBytes($dest, $data.Content)
                    Write-Host "saved $($job.key).jpg  <= $($cand.title)  ($([math]::Round($data.Content.Length/1kb)) KB, $($cand.w)x$($cand.h))"
                    $ok = $true
                    break
                }
            } catch { Write-Host "  cand failed: $($_.Exception.Message)" }
        }
    } catch { Write-Host "FAILED $($job.key): $($_.Exception.Message)" }
    if (-not $ok -and (Test-Path $dest) -eq $false) { Write-Host "FAILED $($job.key)" }
    Start-Sleep -Seconds 8
}
Write-Host "done"
