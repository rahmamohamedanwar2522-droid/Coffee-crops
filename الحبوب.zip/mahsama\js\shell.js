/* ============================================================
   الهيدر والفوتر — يُبنى تلقائيًا في كل صفحة
   (يُستدعى قبل ui.js حتى تعمل أزرار السلة والبحث)
   ============================================================ */
(function () {
  var S = window.SITE || {};
  var wa = String(S.whatsapp || "").replace(/[^\d]/g, "");

  var nav = [
    { href: "index.html", label: "الرئيسية" },
    { href: "shop.html", label: "كل المنتجات" },
    { href: "shop.html?cat=coffee", label: "القهوة والبن" },
    { href: "shop.html?cat=specialty", label: "القهوة المختصة" },
    { href: "shop.html?cat=offers", label: "العروض والخصومات" },
    { href: "contact.html", label: "تواصل معنا" }
  ];

  var header =
    '<header class="site-header">' +
      '<div class="header-inner">' +
        '<a class="brand" href="index.html">' +
          '<span class="brand-logo">ح</span>' +
          '<span><span class="brand-name">' + (S.name || "الحبوب") + '</span>' +
          '<span class="brand-sub" style="display:block">' + (S.tagline || "") + '</span></span>' +
        '</a>' +
        '<span class="header-spacer"></span>' +
        '<form class="header-search" data-header-search role="search">' +
          '<input type="search" placeholder="ابحث عن منتج…" aria-label="البحث في المنتجات">' +
          '<button type="submit" aria-label="بحث">🔍</button>' +
        '</form>' +
        '<a class="cart-link" href="cart.html">🛒 السلة <span class="cart-badge" data-cart-count>0</span></a>' +
        '<button class="nav-toggle" data-nav-toggle aria-expanded="false" aria-label="القائمة">☰</button>' +
      '</div>' +
      '<nav class="main-nav" id="mainNav" data-nav><ul>' +
        nav.map(function (n) {
          return '<li><a href="' + n.href + '">' + n.label + "</a></li>";
        }).join("") +
      '</ul></nav>' +
    "</header>";

  var footer =
    '<footer class="site-footer">' +
      '<div class="footer-grid">' +
        '<div>' +
          '<div class="footer-brand"><span class="brand-logo">ح</span>' +
          '<b>' + (S.name || "الحبوب") + "</b></div>" +
          '<p>' + (S.tagline || "") + '</p>' +
          '<p style="margin-top:10px">' + (S.notes ? S.notes.cashOnDelivery : "") + "</p>" +
        "</div>" +
        "<div><h4>روابط سريعة</h4><ul>" +
          '<li><a href="shop.html">كل المنتجات</a></li>' +
          '<li><a href="shop.html?cat=coffee">القهوة والبن</a></li>' +
          '<li><a href="shop.html?cat=specialty">القهوة المختصة</a></li>' +
          '<li><a href="shop.html?cat=offers">العروض والخصومات</a></li>' +
          '<li><a href="cart.html">سلة المشتريات</a></li>' +
          '<li><a href="checkout.html">إتمام الطلب</a></li>' +
        "</ul></div>" +
        "<div><h4>تواصل معنا</h4><ul>" +
          "<li>📞 " + (S.phoneDisplay || "") + "</li>" +
          "<li>📍 " + (S.address || "") + "</li>" +
          "<li>🕘 " + (S.workingHours || "") + "</li>" +
          '<li><a href="' + (wa ? "https://wa.me/" + wa : "contact.html") + '" target="_blank" rel="noopener">💬 طلب عبر واتساب</a></li>' +
        "</ul></div>" +
      "</div>" +
      '<div class="footer-bottom">© <span data-year></span> <b>' + (S.name || "الحبوب") +
        "</b> — كل الحقوق محفوظة | الأسعار المعروضة تجريبية وقابلة للتعديل</div>" +
    "</footer>" +
    (wa ? '<a class="wa-float" href="https://wa.me/' + wa + '" target="_blank" rel="noopener" aria-label="واتساب">💬' : "");

  var h = document.getElementById("siteHeader");
  if (h) h.outerHTML = header;
  var f = document.getElementById("siteFooter");
  if (f) f.outerHTML = footer;
})();
