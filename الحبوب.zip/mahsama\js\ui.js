/* ============================================================
   واجهة مشتركة: الهيدر، السلة، البحث، الصور البديلة، التنبيهات
   ============================================================ */
(function () {
  var SITE = window.SITE || {};

  /* ---------- أرقام وعملة ---------- */
  function money(n) {
    n = Number(n) || 0;
    return n.toLocaleString("en-US") + " " + (SITE.currency || "ج.م");
  }

  /* ---------- صورة بديلة أنيقة عند تعذّر الصورة ---------- */
  function placeholder(label, kind) {
    var bg = kind === "crops" ? "#3B2A16" : "#2A1810";
    var accent = "#C9A24B";
    var icon = kind === "crops"
      ? '<path d="M100 40c-14 12-20 30-20 48s6 36 20 48c14-12 20-30 20-48s-6-36-20-48z" fill="none" stroke="' + accent + '" stroke-width="5"/><path d="M100 55v90" stroke="' + accent + '" stroke-width="3"/>'
      : '<ellipse cx="100" cy="100" rx="34" ry="46" fill="none" stroke="' + accent + '" stroke-width="5"/><path d="M100 56c-14 24-14 64 0 88" fill="none" stroke="' + accent + '" stroke-width="5"/>';
    var text = String(label || "").slice(0, 22);
    var svg =
      '<svg xmlns="http://www.w3.org/2000/svg" width="600" height="450" viewBox="0 0 600 450">' +
      '<rect width="600" height="450" fill="' + bg + '"/>' +
      '<rect x="14" y="14" width="572" height="422" fill="none" stroke="' + accent + '" stroke-opacity=".55" stroke-width="2"/>' +
      '<g transform="translate(200,80) scale(1)">' + icon + "</g>" +
      '<text x="300" y="300" fill="' + accent + '" font-size="30" text-anchor="middle" font-family="Tajawal, Segoe UI, Arial">' + escapeXml(text) + "</text>" +
      '<text x="300" y="345" fill="#F8F1E5" fill-opacity=".8" font-size="20" text-anchor="middle" font-family="Tajawal, Segoe UI, Arial">الحبوب</text>' +
      "</svg>";
    return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
  }

  function escapeXml(s) {
    return String(s).replace(/[<>&'"]/g, function (c) {
      return { "<": "&lt;", ">": "&gt;", "&": "&amp;", "'": "&apos;", '"': "&quot;" }[c];
    });
  }

  /** يضبط الصورة بحيث يستبدلها بـ placeholder عند الفشل */
  function bindImage(imgEl, label, kind) {
    if (!imgEl) return;
    imgEl.addEventListener("error", function () {
      if (imgEl.dataset.fallback === "1") return;
      imgEl.dataset.fallback = "1";
      imgEl.src = placeholder(label, kind);
    });
    // إذا كانت الصورة مُحمّلة مسبقًا وفشلت بالفعل
    if (imgEl.complete && imgEl.naturalWidth === 0 && imgEl.getAttribute("src")) {
      imgEl.dispatchEvent(new Event("error"));
    }
  }

  function productImage(p) {
    return p.image || placeholder(p.name, p.category);
  }

  /* ---------- إشعار صغير ---------- */
  var toastTimer = null;
  function toast(msg, tone) {
    var el = document.getElementById("siteToast");
    if (!el) {
      el = document.createElement("div");
      el.id = "siteToast";
      el.className = "site-toast";
      document.body.appendChild(el);
    }
    el.textContent = msg;
    el.style.background = tone === "error" ? "#8A2F2A" : "#2A1810";
    el.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { el.classList.remove("show"); }, 2400);
  }

  /* ---------- رقم السلة في الهيدر ---------- */
  function refreshBadges() {
    var n = window.Cart ? Cart.count() : 0;
    document.querySelectorAll("[data-cart-count]").forEach(function (b) {
      b.textContent = n;
      b.classList.toggle("hidden", n === 0);
    });
  }

  /* ---------- رسالة واتساب ---------- */
  function whatsappLink(text) {
    var num = String(SITE.whatsapp || "").replace(/[^\d]/g, "");
    return "https://wa.me/" + num + "?text=" + encodeURIComponent(text);
  }

  /** totalOverride: إجمالي مخصص (مثلاً عند طلب منتج واحد) */
  function orderText(items, customer, totalOverride) {
    var lines = [];
    lines.push("طلب جديد من " + (SITE.name || ""));
    lines.push("");
    var sum = 0;
    items.forEach(function (it, i) {
      var lineTotal = typeof it.lineTotal === "number" ? it.lineTotal : it.product.price * it.qty;
      sum += lineTotal;
      lines.push((i + 1) + ") " + it.product.name + " — " + it.product.weight +
        " × " + it.qty + " = " + money(lineTotal));
    });
    lines.push("");
    lines.push("الإجمالي: " + money(typeof totalOverride === "number" ? totalOverride : (Cart.subtotal() || sum)));
    if (customer) {
      lines.push("");
      lines.push("الاسم: " + customer.name);
      lines.push("الهاتف: " + customer.phone);
      lines.push("العنوان: " + customer.address);
      if (customer.note) lines.push("ملاحظات: " + customer.note);
    }
    lines.push("");
    lines.push("طريقة الدفع: عند الاستلام");
    return lines.join("\n");
  }

  /* ---------- بحث عام من الهيدر ---------- */
  function wireHeaderSearch() {
    var form = document.querySelector("[data-header-search]");
    if (!form) return;
    var input = form.querySelector("input");
    // ملء الحقل من معلمة q عند فتح صفحة المنتجات
    if (location.pathname.indexOf("shop") > -1) {
      var q = new URLSearchParams(location.search).get("q");
      if (q && input) input.value = q;
    }
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var v = (input && input.value || "").trim();
      var target = "shop.html";
      location.href = v ? target + "?q=" + encodeURIComponent(v) : target;
    });
  }

  /* ---------- قائمة الموبايل ---------- */
  function wireMobileNav() {
    var btn = document.querySelector("[data-nav-toggle]");
    var nav = document.getElementById("mainNav");
    if (!btn || !nav) return;
    btn.addEventListener("click", function () {
      var open = nav.classList.toggle("open");
      btn.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  /* ---------- تمييز الصفحة الحالية ---------- */
  function markActiveNav() {
    var file = location.pathname.split("/").pop() || "index.html";
    document.querySelectorAll("[data-nav] a").forEach(function (a) {
      var href = a.getAttribute("href");
      if (href === file || (file === "" && href === "index.html")) a.classList.add("active");
    });
  }

  /* ---------- بطاقة منتج مشتركة ---------- */
  function productCard(p) {
    var off = p.oldPrice && p.oldPrice > p.price
      ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;
    var cat = (window.CATEGORIES && window.CATEGORIES[p.category]) || "";
    return (
      '<article class="card" data-product-card data-id="' + p.id + '">' +
      '<a class="card-media" href="product.html?id=' + encodeURIComponent(p.id) + '">' +
      '<img src="' + p.image + '" alt="' + escapeXml(p.name) + '" data-img="' + escapeXml(p.name) + '" data-kind="' + p.category + '">' +
      (p.badge ? '<span class="chip chip-badge">' + escapeXml(p.badge) + "</span>" : "") +
      (off ? '<span class="chip chip-off">خصم ' + off + "٪</span>" : "") +
      "</a>" +
      '<div class="card-body">' +
      '<span class="card-cat">' + cat + "</span>" +
      '<h3 class="card-title"><a href="product.html?id=' + encodeURIComponent(p.id) + '">' + escapeXml(p.name) + "</a></h3>" +
      '<div class="card-meta"><span class="weight">' + escapeXml(p.weight) + "</span></div>" +
      '<div class="card-price">' +
      '<span class="price">' + money(p.price) + "</span>" +
      (off ? '<span class="old-price">' + money(p.oldPrice) + "</span>" : "") +
      "</div>" +
      '<div class="card-actions">' +
      '<button class="btn btn-gold btn-sm" data-add="' + p.id + '">أضف للسلة</button>' +
      '<a class="btn btn-ghost btn-sm" href="product.html?id=' + encodeURIComponent(p.id) + '">التفاصيل</a>' +
      "</div></div></article>"
    );
  }

  /** يبني شبكة منتجات ويصلّح الصور ويربط الأزرار */
  function renderGrid(container, list) {
    if (!container) return;
    if (!list.length) {
      container.innerHTML = '<p class="empty">لا توجد منتجات مطابقة لبحثك. جرّب كلمة أخرى أو اختر "الكل".</p>';
      return;
    }
    container.innerHTML = list.map(productCard).join("");
    container.querySelectorAll("img[data-img]").forEach(function (img) {
      bindImage(img, img.dataset.img, img.dataset.kind);
    });
  }

  /* ---------- تفويض: أزرار الإضافة في أي صفحة ---------- */
  function wireAddButtons(root) {
    (root || document).addEventListener("click", function (e) {
      var btn = e.target.closest("[data-add]");
      if (!btn) return;
      e.preventDefault();
      var id = btn.getAttribute("data-add");
      var qtyInput = document.querySelector("[data-qty-input]");
      var qty = 1;
      if (qtyInput && btn.hasAttribute("data-use-qty")) qty = parseInt(qtyInput.value, 10) || 1;
      if (Cart.add(id, qty)) {
        refreshBadges();
        var p = (window.PRODUCTS || []).filter(function (x) { return x.id === id; })[0];
        toast("تمت إضافة " + (p ? p.name : "المنتج") + " إلى السلة ✓");
      } else {
        toast("تعذّر إضافة المنتج", "error");
      }
    });
  }

  document.addEventListener("DOMContentLoaded", function () {
    wireHeaderSearch();
    wireMobileNav();
    markActiveNav();
    wireAddButtons();
    refreshBadges();
    // صور الهيدر/الهوم إن وُجدت
    document.querySelectorAll("img[data-img]").forEach(function (img) {
      bindImage(img, img.dataset.img, img.dataset.kind);
    });
    var yearEl = document.querySelectorAll("[data-year]");
    yearEl.forEach(function (el) { el.textContent = new Date().getFullYear(); });
    // ظهور تدريجي للأقسام
    if ("IntersectionObserver" in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) {
          if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
        });
      }, { threshold: 0.12 });
      document.querySelectorAll("[data-reveal]").forEach(function (el) { io.observe(el); });
    } else {
      document.querySelectorAll("[data-reveal]").forEach(function (el) { el.classList.add("in"); });
    }
  });

  window.UI = {
    money: money,
    toast: toast,
    bindImage: bindImage,
    placeholder: placeholder,
    productImage: productImage,
    productCard: productCard,
    renderGrid: renderGrid,
    refreshBadges: refreshBadges,
    whatsappLink: whatsappLink,
    orderText: orderText,
    escapeXml: escapeXml
  };
})();
