﻿# ============================================================
#  تشغيل موقع «الحبوب» على http://localhost:8080
#  يستقبل اتصالات هذا الجهاز + أجهزة شبكة الواي فاي المحلية.
#  لا يحتاج أي تثبيت — يعمل بأدوات ويندوز فقط.
#
#  التشغيل:
#    powershell -ExecutionPolicy Bypass -File serve.ps1
#
#  مرة واحدة فقط (قبل أول تشغيل للشبكة) — إعداد صلاحيات
#  بصلاحية مسؤول (Run as Administrator):
#    powershell -ExecutionPolicy Bypass -File tools\lan-setup.ps1
#
#  لإيقاف الخادم: اضغط Ctrl+C داخل نافذة PowerShell
# ============================================================
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$port = 8080

$mime = @{
  ".html"="text/html; charset=utf-8"; ".css"="text/css; charset=utf-8";
  ".js"="application/javascript; charset=utf-8"; ".json"="application/json; charset=utf-8";
  ".jpg"="image/jpeg"; ".jpeg"="image/jpeg"; ".png"="image/png";
  ".svg"="image/svg+xml"; ".webp"="image/webp"; ".ico"="image/x-icon";
  ".woff2"="font/woff2"; ".txt"="text/plain; charset=utf-8"; ".md"="text/plain; charset=utf-8"
}

# --- الاستماع على كل الشبكات (http://+:8080/) لقبول أجهزة الواي فاي ---
# إذا لم تكن الصلاحية متاحة، نعود إلى localhost ويظهر تنبيه بخطوات الإعداد.
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://+:$port/")
$boundAll = $true
try {
  $listener.Start()
} catch {
  $listener = New-Object System.Net.HttpListener
  $listener.Prefixes.Add("http://localhost:$port/")
  try {
    $listener.Start()
    $boundAll = $false
  } catch {
    Write-Host "تعذّر فتح المنفذ $port — قد يكون مشغولًا. جرّب منفذًا آخر أو أوقف الخادم الآخر." -ForegroundColor Red
    exit 1
  }
}

# عناوين الشبكة المحلية (Wi-Fi / Ethernet) لعرضها للمستخدم
$lanIPs = @(Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue |
  Where-Object { $_.IPAddress -notlike "127.*" -and $_.IPAddress -notlike "169.254.*" -and $_.IPAddress -ne "0.0.0.0" } |
  ForEach-Object { $_.IPAddress } | Select-Object -Unique)

Write-Host "الحبوب — الخادم يعمل على المنفذ $port" -ForegroundColor Green
Write-Host "على هذا الجهاز:" -ForegroundColor Yellow
Write-Host "   http://localhost:$port" -ForegroundColor Yellow
if ($boundAll -and $lanIPs.Count -gt 0) {
  Write-Host "من أي جهاز على نفس شبكة الواي فاي:" -ForegroundColor Yellow
  foreach ($ip in $lanIPs) { Write-Host "   http://${ip}:$port" -ForegroundColor Cyan }
} elseif (-not $boundAll) {
  Write-Host "⚠ يعمل على هذا الجهاز فقط (localhost) — لقبول أجهزة الشبكة شغّل مرة واحدة بصلاحية مسؤول:" -ForegroundColor Red
  Write-Host "   powershell -ExecutionPolicy Bypass -File tools\lan-setup.ps1" -ForegroundColor Red
}
Write-Host "اضغط Ctrl+C لإيقاف الخادم." -ForegroundColor Gray

$utf8 = New-Object System.Text.UTF8Encoding $false

while ($listener.IsListening) {
  try {
    $ctx = $listener.GetContext()
    $path = [Uri]::UnescapeDataString($ctx.Request.Url.AbsolutePath).TrimStart("/")
    if (-not $path -or $path.EndsWith("/")) { $path = $path + "index.html" }

    $file = Join-Path $root $path
    # منع الخروج عن مجلد الموقع
    if (-not $file.StartsWith($root, [System.StringComparison]::OrdinalIgnoreCase)) {
      $ctx.Response.StatusCode = 403; $ctx.Response.Close(); continue
    }
    if (Test-Path $file -PathType Container) { $file = Join-Path $file "index.html" }

    if (Test-Path $file -PathType Leaf) {
      $bytes = [System.IO.File]::ReadAllBytes($file)
      $ext = [System.IO.Path]::GetExtension($file).ToLower()
      $ctx.Response.ContentType = $(if ($mime.ContainsKey($ext)) { $mime[$ext] } else { "application/octet-stream" })
      $ctx.Response.ContentLength64 = $bytes.Length
      $ctx.Response.OutputStream.Write($bytes, 0, $bytes.Length)
    } else {
      $msg = $utf8.GetBytes("<h1 style='font-family:Tahoma' dir='rtl'>404 — الصفحة غير موجودة</h1><a href='/'>العودة للرئيسية</a>")
      $ctx.Response.StatusCode = 404
      $ctx.Response.ContentType = "text/html; charset=utf-8"
      $ctx.Response.OutputStream.Write($msg, 0, $msg.Length)
    }
    $ctx.Response.Close()
  } catch { }
}
